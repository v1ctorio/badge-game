# HOST

import badge


class App(badge.BaseApp):
    def __init__(self):
        super().__init__()
    def show_buttons(self):
        self.logger.info("this app just launched! its listening for")
        badge.display.rect(x: 10, y: 10, w: 10, h: 10, color: 10)
        badge.display.show()
